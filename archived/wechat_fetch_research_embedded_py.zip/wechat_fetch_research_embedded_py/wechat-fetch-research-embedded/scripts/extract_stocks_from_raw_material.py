#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extract stock-level research info from raw_material markdown and merge into stocks_master JSON.

- Reads raw_material markdown formatted by fetch_wechat_to_raw_material.py ("## Article" blocks)
- Uses LLM (OpenAI-compatible) to:
  1) identify mentioned stocks (name/code)
  2) extract accidents/insights/key_metrics/target_valuation per stock for each article
- Maps stocks to a master list Excel (two columns: 股票代码, 股票简称)
- Merges into a JSON file following references/数据结构规范_v2.md

This script is intentionally opinionated for reliability and repeatability.
"""

import argparse
import datetime as dt
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from openai import OpenAI


# ---------------------------
# Utilities
# ---------------------------

def read_text(path: str) -> str:
    return Path(path).read_text(encoding="utf-8").replace("\r\n", "\n")


def write_json(path: str, obj: Any):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def load_stock_map(xls_path: str) -> Tuple[Dict[str, str], Dict[str, str]]:
    """Return (code_digits->name, name->code_digits)."""
    xls = pd.ExcelFile(xls_path)
    df = pd.read_excel(xls_path, sheet_name=xls.sheet_names[0])
    df = df[["股票代码", "股票简称"]].dropna()

    code_to_name = {}
    name_to_code = {}

    for _, r in df.iterrows():
        code_raw = str(r["股票代码"]).strip()
        name = str(r["股票简称"]).strip()
        if not code_raw or not name:
            continue
        # code like 000001.SZ
        m = re.match(r"^(\d{6})\.(SZ|SH)$", code_raw)
        if m:
            code = m.group(1)
            code_to_name[code] = name
            # Keep first mapping if duplicates
            name_to_code.setdefault(name, code)

    return code_to_name, name_to_code


def board_from_code(code_digits: str) -> str:
    # crude fallback
    if code_digits.startswith("6"):
        return "SH"
    return "SZ"


def normalize_url(url: str) -> str:
    return url.replace("\\_", "_")


def compress_accident(s: str, limit: int = 60) -> str:
    s = re.sub(r"^[\s\d一二三四五六七八九十]+[、\.．)]\s*", "", s.strip())
    s = re.sub(r"[#【】]", "", s)
    s = re.sub(r"\s+", " ", s)
    if len(s) <= limit:
        return s
    return s[:40].rstrip() + "..."


@dataclass
class ArticleBlock:
    source: str
    fetched_at: str
    title: str
    date: str
    content: str


def parse_raw_material(md: str, default_date: str) -> List[ArticleBlock]:
    blocks: List[ArticleBlock] = []

    # Split by heading marker (support file starting with '## Article')
    parts = re.split(r"(?m)^## Article\s*$", md)
    for part in parts[1:]:
        # Ensure consistent trimming
        part = part.lstrip("\n")
        # part begins with metadata lines
        lines = part.strip("\n").split("\n")
        meta = {}
        content_lines = []
        in_meta = True
        for ln in lines:
            if in_meta and re.match(r"^(source|fetched_at|title|date):\s*", ln.strip()):
                k, v = ln.split(":", 1)
                meta[k.strip()] = v.strip()
            else:
                in_meta = False
                content_lines.append(ln)

        # strip trailing separator
        content = "\n".join(content_lines)
        content = re.sub(r"\n---\s*$", "", content.strip(), flags=re.S)

        source = normalize_url(meta.get("source", "").strip())
        if not source:
            continue
        blocks.append(
            ArticleBlock(
                source=source,
                fetched_at=meta.get("fetched_at", "").strip(),
                title=meta.get("title", "").strip(),
                date=meta.get("date", "").strip() or default_date,
                content=content.strip(),
            )
        )

    return blocks


# ---------------------------
# LLM
# ---------------------------

def llm_json(client: OpenAI, model: str, system: str, user: str) -> Any:
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=0,
    )
    txt = resp.choices[0].message.content.strip()
    # allow fenced json
    txt = re.sub(r"^```json\s*", "", txt)
    txt = re.sub(r"```\s*$", "", txt)
    return json.loads(txt)


SYSTEM_IDENTIFY = (
    "你是中文金融研报信息抽取助手。任务：从公众号文章正文中识别提到的A股个股名称/代码。\n"
    "约束：\n"
    "- 只输出 JSON（不要解释、不要 markdown）。\n"
    "- 若不确定，宁可不输出。\n"
    "- 允许输出 name 或 code（6位数字），能给 code 优先给 code。\n"
    "输出格式示例：{\"stocks\":[{\"name\":\"新雷能\",\"code\":\"300593\"}]}"
)

SYSTEM_EXTRACT = (
    "你是中文金融研报结构化抽取助手。\n"
    "你会收到：\n"
    "1) 一篇公众号文章（可能包含多只股票内容）\n"
    "2) 需要抽取的股票列表（已经映射到代码）\n"
    "请为每只股票生成一条 article 记录，字段必须符合下列 JSON Schema：\n"
    "{\n"
    "  \"items\": [\n"
    "    {\n"
    "      \"code\": \"6位数字\",\n"
    "      \"name\": \"股票简称\",\n"
    "      \"article\": {\n"
    "        \"title\": \"文章标题（尽量从文中提取/概括，不要空）\",\n"
    "        \"date\": \"YYYY-MM-DD\",\n"
    "        \"source\": \"文章链接\",\n"
    "        \"accidents\": [\"事件/催化剂/行业新闻（短句）\"],\n"
    "        \"insights\": [\"投研观点/逻辑（可长文本）\"],\n"
    "        \"key_metrics\": [\"关键指标/量化信息\"],\n"
    "        \"target_valuation\": [\"估值/目标市值/空间测算\"]\n"
    "      }\n"
    "    }\n"
    "  ]\n"
    "}\n"
    "抽取规则：\n"
    "- accidents：只写事实事件，不写推理；单条尽量<=60字。\n"
    "- insights：保留原文或忠实改写，允许较长。\n"
    "- key_metrics：只放指标/数字/市占率/产能/价格/财务等。\n"
    "- target_valuation：估值、目标价/目标市值、空间测算等。\n"
    "- 如果某字段无信息，输出空数组 []（不要 null）。\n"
    "- 只输出 JSON，不要解释。"
)


def identify_stocks_in_article(client: OpenAI, model: str, article_text: str) -> List[Dict[str, str]]:
    user = f"文章正文如下（用三引号包裹）：\n\n'''\n{article_text}\n'''"
    obj = llm_json(client, model, SYSTEM_IDENTIFY, user)
    stocks = obj.get("stocks", []) if isinstance(obj, dict) else []
    out = []
    for s in stocks:
        if not isinstance(s, dict):
            continue
        name = str(s.get("name", "")).strip()
        code = str(s.get("code", "")).strip()
        if code and re.fullmatch(r"\d{6}", code):
            out.append({"code": code, "name": name})
        elif name:
            out.append({"code": "", "name": name})
    return out


def extract_items(client: OpenAI, model: str, article: ArticleBlock, mapped_stocks: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    stock_lines = "\n".join([f"- {s['name']} ({s['code']})" for s in mapped_stocks])
    user = (
        f"股票列表：\n{stock_lines}\n\n"
        f"文章链接：{article.source}\n"
        f"文章日期：{article.date}\n"
        f"文章标题（可能为空）：{article.title}\n\n"
        f"正文如下（三引号包裹）：\n\n'''\n{article.content}\n'''"
    )
    obj = llm_json(client, model, SYSTEM_EXTRACT, user)
    items = obj.get("items", []) if isinstance(obj, dict) else []
    return items if isinstance(items, list) else []


# ---------------------------
# Merge
# ---------------------------

def ensure_stock_base(code: str, name: str) -> Dict[str, Any]:
    return {
        "name": name,
        "code": code,
        "board": board_from_code(code),
        "industry": "",
        "concepts": [],
        "products": [],
        "core_business": [],
        "industry_position": [],
        "chain": [],
        "partners": [],
        "mention_count": 0,
        "articles": [],
    }


def merge_into_master(master: Dict[str, Any], items: List[Dict[str, Any]]):
    stocks = master.setdefault("stocks", [])
    by_code = {s.get("code"): s for s in stocks if isinstance(s, dict) and s.get("code")}

    for it in items:
        if not isinstance(it, dict):
            continue
        code = str(it.get("code", "")).strip()
        name = str(it.get("name", "")).strip()
        art = it.get("article", {})
        if not (re.fullmatch(r"\d{6}", code) and isinstance(art, dict)):
            continue

        s = by_code.get(code)
        if not s:
            s = ensure_stock_base(code, name or code)
            stocks.append(s)
            by_code[code] = s

        # de-dupe by source
        src = normalize_url(str(art.get("source", "")).strip())
        if not src:
            continue
        existing_sources = {a.get("source") for a in s.get("articles", []) if isinstance(a, dict)}
        if src in existing_sources:
            continue

        # normalize arrays
        for k in ["accidents", "insights", "key_metrics", "target_valuation"]:
            v = art.get(k, [])
            if not isinstance(v, list):
                v = []
            if k == "accidents":
                v = [compress_accident(str(x)) for x in v if str(x).strip()]
            else:
                v = [str(x).strip() for x in v if str(x).strip()]
            art[k] = v

        art["source"] = src
        art["date"] = str(art.get("date") or "").strip() or dt.date.today().isoformat()
        art["title"] = str(art.get("title") or "").strip()

        s.setdefault("articles", []).append(
            {
                "title": art["title"],
                "date": art["date"],
                "source": art["source"],
                "accidents": art["accidents"],
                "insights": art["insights"],
                "key_metrics": art["key_metrics"],
                "target_valuation": art["target_valuation"],
            }
        )
        s["mention_count"] = len(s.get("articles", []))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", required=True, help="raw_material markdown file")
    ap.add_argument("--stock_xls", required=True, help="Excel mapping: 股票代码, 股票简称")
    ap.add_argument("--out_json", required=True, help="Output JSON path")
    ap.add_argument("--mode", choices=["overwrite", "merge"], default="merge")
    ap.add_argument("--model", default=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"))
    ap.add_argument("--default_date", default=dt.date.today().isoformat())
    args = ap.parse_args()

    code_to_name, name_to_code = load_stock_map(args.stock_xls)

    raw_md = read_text(args.raw)
    articles = parse_raw_material(raw_md, default_date=args.default_date)
    if not articles:
        raise SystemExit("No article blocks found in raw_material. Expect '## Article' blocks.")

    client = OpenAI()

    master = {"stocks": []}
    out_path = Path(args.out_json)
    if args.mode == "merge" and out_path.exists():
        master = json.loads(out_path.read_text(encoding="utf-8"))
        if not isinstance(master, dict):
            master = {"stocks": []}

    for art in articles:
        # Step A: identify mentioned stocks
        candidates = identify_stocks_in_article(client, args.model, art.content)

        mapped: List[Dict[str, str]] = []
        for c in candidates:
            code = c.get("code", "")
            name = c.get("name", "")

            if code and code in code_to_name:
                mapped.append({"code": code, "name": code_to_name[code]})
                continue

            if name and name in name_to_code:
                mapped.append({"code": name_to_code[name], "name": name})

        # de-dup
        uniq = {}
        for s in mapped:
            uniq[s["code"]] = s
        mapped = list(uniq.values())

        if not mapped:
            continue

        # Step B: extract structured items
        items = extract_items(client, args.model, art, mapped)

        # Fill missing name via map if needed
        for it in items:
            if isinstance(it, dict) and re.fullmatch(r"\d{6}", str(it.get("code", ""))):
                code = str(it["code"])
                it.setdefault("name", code_to_name.get(code, ""))
                if isinstance(it.get("article"), dict):
                    it["article"].setdefault("source", art.source)
                    it["article"].setdefault("date", art.date)
                    it["article"].setdefault("title", art.title)

        merge_into_master(master, items)

    write_json(args.out_json, master)
    print(args.out_json)


if __name__ == "__main__":
    main()
