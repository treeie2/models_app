---
name: wechat-fetch-research-embedded
description: 把微信公众号文章链接转成可结构化投研素材并沉淀到 JSON 数据库的工作流技能（增强版：内置《全部个股.xls》和《数据结构规范_v2》）。适用场景：你给出一个或多个 mp.weixin.qq.com 链接，需要（1）可靠读取公众号正文并落盘 raw_material；（2）从 raw_material 识别提到的个股（自动映射内置 stock list）；（3）按内置《数据结构规范_v2》抽取 accidents/insights/key_metrics/target_valuation，并增量合并写入 stocks_master_*.json；（4）可选同步到 Firestore（凭证建议放在 workspace/secrets，避免嵌入 skill）。
---

# wechat-fetch-research-embedded

## 快速开始（推荐工作流）

**输入**：微信公众号文章 URL（单篇或多篇）

**输出**：
- `raw_material/raw_material_YYYY-MM-DD.md`（原始正文沉淀）
- `data/stocks_master_YYYY-MM-DD.json`（按规范聚合后的结构化数据，可增量追加）
- （可选）同步到 Firebase Firestore（collection: `stocks`，docId: `stock_code`，按 source 增量追加 articles）

> 数据结构以 `references/数据结构规范_v2.md` 为准。

## Step 1：抓取公众号正文 → 写入 raw_material

公众号经常出现“环境异常/去验证/反爬”，导致 **直接 HTTP 抓取失败或拿不到全文**。本技能提供两种方式：

### 方式 A：外部 Reader（可选）
如果你有可用的 link reader / 代理 / 可访问环境（例如 MCP reader），可直接把正文喂给落盘脚本：

- `python scripts/fetch_wechat_to_raw_material.py --url "<mp_url>" --out "raw_material/raw_material_2026-04-03.md" --mcp_server <server_name> --mcp_tool <tool_name>`

### 方式 B：浏览器登录态抓取（推荐，最稳）
本技能内置 **Playwright 浏览器 DOM 抽取**，不尝试绕过微信安全机制；如遇“去验证/登录”，你需要在弹出的真实浏览器里手动完成一次验证。

1) 先用浏览器抓取正文到临时文件：
- `python scripts/fetch_wechat_via_browser_dom.py --url "<mp_url>" --out_text "tmp_article.txt" --user_data_dir ".browser_profile" --timeout 300`

2) 再把临时正文落盘为 raw_material：
- `python scripts/fetch_wechat_to_raw_material.py --url "<mp_url>" --out "raw_material/raw_material_2026-04-03.md" --manual_text_file "tmp_article.txt"`

> 说明：`--manual_text_file` 模式等价于“外部 reader 已经拿到正文”，脚本负责 **统一 raw_material 结构**（source/fetched_at/title/date + content）。

## Step 2：从 raw_material 抽取个股结构化信息 → 追加写入 JSON

- `python scripts/extract_stocks_from_raw_material.py \
  --raw "raw_material/raw_material_2026-04-03.md" \
  --stock_xls "./assets/全部个股.xls" \
  --out_json "data/stocks_master_2026-04-03.json" \
  --mode merge`

> 说明：本 skill **已内置** `assets/全部个股.xls` 与 `references/数据结构规范_v2.md`，因此不需要你每次从外部上传。

## Step 3（可选）：同步 JSON 到 Firebase Firestore（避免整文档写回）

### 前置条件
- 需要 **Firebase Admin Service Account** JSON（私钥文件），不要用前端 `apiKey`。
- 出于安全原因，**不建议把私钥嵌进 skill**。推荐放在：`/home/user/workspace/secrets/firebase-credentials.json`（你只需放一次）。

### Firestore 数据模型（推荐）
- 股票文档：`stocks/{stock_code}`（只写入股票基础字段 + 计数）
- 文章子集合：`stocks/{stock_code}/articles/{article_id}`
  - `article_id = sha1(source)`（天然去重）

### 同步命令
- `python scripts/sync_to_firestore.py \
  --credentials "/home/user/workspace/secrets/firebase-credentials.json" \
  --json "data/stocks_master_2026-04-03.json" \
  --collection "stocks" \
  --article_subcollection "articles" \
  --on_exists skip`

同步规则（关键点）：
- **不再把 articles 数组写回 stocks 文档**（避免整文档写回）
- 每篇文章单独写入子集合 doc（按 source 哈希去重）
- 仅当新文章写入成功时，使用事务对 `stocks/{code}` 的 `article_count`/`mention_count` 做 `Increment(1)`
- 已存在文章默认 `skip`（你也可以用 `--on_exists update` 更新内容）

抽取规则（核心点）：
- **先识别个股**：从 raw_material 中抽取“候选个股名/代码” → 映射到《全部个股.xls》（代码+简称）。
- **再按文章维度抽字段**：对每篇文章、每只股票，抽取：
  - `accidents`：事件/催化剂/行业新闻（短句，超 60 字需压缩）
  - `insights`：投研观点/逻辑
  - `key_metrics`：量化指标/市占率/财务/产能等
  - `target_valuation`：估值/目标市值/空间/测算
- **结构化输出**：组织成 `stocks[].articles[]`，并按 `source`（URL）去重追加。

## 目录约定

建议在项目根目录使用如下结构（脚本默认会自动创建目录）：

- `raw_material/`：原始文章正文沉淀（Markdown）
- `data/`：结构化 JSON 输出

## 关键资源

- **数据结构规范**：`references/数据结构规范_v2.md`
- **脚本**：
  - `scripts/fetch_wechat_to_raw_material.py`：把正文统一落盘为 raw_material（支持外部 reader 或手动正文）
  - `scripts/fetch_wechat_via_browser_dom.py`：用真实浏览器登录态从 DOM 抽取公众号全文（遇到“去验证”需人工点一次）
  - `scripts/extract_stocks_from_raw_material.py`：LLM 抽取并合并到 stocks_master JSON
- `scripts/sync_to_firestore.py`：将 stocks_master JSON **增量同步**到 Firebase Firestore（需 service account）

## 常见坑（务必看）

1. **公众号“去验证”**：遇到验证页时，需要在浏览器里人工点一下，验证通过后再抽正文。
2. **公众号反爬**：直接抓 HTML 常失败或内容不全；优先用“浏览器 DOM 提取正文”兜底。
3. **股票简称歧义**：抽取到的简称可能是同名词/简称重叠；脚本会尽量映射到《全部个股.xls》，无法映射则不入库。
4. **增量合并**：`--mode merge` 会保留既有 stocks 并追加新文章；同一 `source` 不重复写入。
